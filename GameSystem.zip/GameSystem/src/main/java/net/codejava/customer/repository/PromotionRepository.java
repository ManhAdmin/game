package net.codejava.customer.repository;

import net.codejava.customer.entity.Promotion;
import org.springframework.data.repository.CrudRepository;

public interface PromotionRepository extends CrudRepository<Promotion, Long>{

}
